package com.first.dao;

import com.first.entity.Login;

public interface RegisterDAO {
	boolean saveDetails(Login login);
}
