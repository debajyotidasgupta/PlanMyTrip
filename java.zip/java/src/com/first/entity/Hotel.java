package com.first.entity;

public class Hotel {
	private int id;
	private String rtype;
	private String rmax;
	private String rview;
	private String rsize;
	private String rbed;
	private String rdesc;
	private int ravail;
	private String rpic;
	public String getRpic() {
		return rpic;
	}
	public void setRpic(String rpic) {
		this.rpic = rpic;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getRtype() {
		return rtype;
	}
	public void setRtype(String rtype) {
		this.rtype = rtype;
	}
	public String getRmax() {
		return rmax;
	}
	public void setRmax(String rmax) {
		this.rmax = rmax;
	}
	public String getRview() {
		return rview;
	}
	public void setRview(String rview) {
		this.rview = rview;
	}
	public String getRsize() {
		return rsize;
	}
	public void setRsize(String rsize) {
		this.rsize = rsize;
	}
	public String getRbed() {
		return rbed;
	}
	public void setRbed(String rbed) {
		this.rbed = rbed;
	}
	public String getRdesc() {
		return rdesc;
	}
	public void setRdesc(String rdesc) {
		this.rdesc = rdesc;
	}
	public int getRavail() {
		return ravail;
	}
	public void setRavail(int ravail) {
		this.ravail = ravail;
	}
	public String getRvid() {
		return rvid;
	}
	public void setRvid(String rvid) {
		this.rvid = rvid;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	private String rvid;
	private String tag;
}
